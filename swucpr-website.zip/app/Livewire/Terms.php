<?php

namespace App\Livewire;

use Livewire\Component;

class Terms extends Component
{
    public function render()
    {
        return view('livewire.terms');
    }
}
