<div>
<ul class="nav-menu">
    <li>
        <a href="#" class="text-white">HOME</a>
    </li>
    <li>
        <a href="/ProjectsNew" class="text-white">PROJECTS</a>
    </li>
    <li>
        <a href="#" class="text-white">FACULTY</a>
    </li>
    <li>
        <a href="/AboutNew" class="text-white">ABOUT</a>
    </li>
</ul>
</div>