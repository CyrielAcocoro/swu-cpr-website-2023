<x-app-layout>
    <livewire:home />
</x-app-layout>