<main class="mb-auto">
    <div class="overflow prose-slate prose-p:text-md dark:prose-invert mx-auto ">
        <div id="facultyElement" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 grid-rows-2 gap-12 py-12 mx-auto max-w-screen-2xl">
            @foreach ($studentDev as $studentDeveloper)
            <x-student-card full-name="{{ $studentDeveloper->full_name }}" email="{{ $studentDeveloper->email }}" city="{{ $studentDeveloper->city }}" province="{{ $studentDeveloper->province }}" country="{{ $studentDeveloper->country }}" image="{{ asset('/admin-images/' . $studentDeveloper->image) }}" githubLink="{{$studentDeveloper->github}}" linkedinLink="{{$studentDeveloper->linkedin}}" />
            @endforeach
        </div>
    </div>
</main>