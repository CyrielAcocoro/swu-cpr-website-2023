<main class="mb-auto">
    <div class="h-80  bg-cover bg-no-repeat bg-center overflow-auto" style="
        background-image: url('/images/education.jpeg');
      ">
        <div class="relative flex flex-col items-center justify-center w-full h-full">
            <div class="absolute inset-0 bg-black opacity-75"></div>
            <div class="relative  text-2xl text-white">
                Illuminating Tech Triumphs
            </div>
        </div>

    </div>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('project-content', []);

$__html = app('livewire')->mount($__name, $__params, 'jaCJxfo', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</main><?php /**PATH C:\Users\acoco\OneDrive\Desktop\swu-cpr-website\resources\views/livewire/project.blade.php ENDPATH**/ ?>